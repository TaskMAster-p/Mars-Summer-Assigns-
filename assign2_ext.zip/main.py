from machine import Pin
import time

STEP = Pin(20 , Pin.OUT)
DIR = Pin(19 , Pin.OUT)
SW = Pin(6 , Pin.IN ,Pin.PULL_UP)
LED_yellow = Pin(11 , Pin.OUT)
LED_green = Pin(12 , Pin.OUT)

def direction(clockwise):
    if clockwise:
        DIR.value(1)
    else:
        DIR.value(0)
def rotation():
    
    STEP.value(1)
    time.sleep_ms(1)
    STEP.value(0)
    time.sleep_ms(1)
    


def func(clockwise):
    direction(clockwise)
    rotation()

while True:
    if SW.value() == 1:
        LED_yellow.on()
        LED_green.off()
        func(True)
    else:
        LED_yellow.off()
        LED_green.on()
        func(False)


    
    
