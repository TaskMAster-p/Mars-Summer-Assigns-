from machine import Pin
import time

STEP = Pin(16 , Pin.OUT)
DIR = Pin(4 , Pin.OUT)
SW = Pin(25 , Pin.IN ,Pin.PULL_UP)
LED = Pin(33 , Pin.OUT)

def direction(clockwise):
    if clockwise:
        DIR.value(1)
    else:
        DIR.value(0)
def rotation():
    for k in range(0,200):
        STEP.value(1)
        time.sleep_ms(1)
        STEP.value(0)
        time.sleep_ms(1)

def func(clockwise):
    direction(clockwise)
    rotation()
while True:
    if SW.value() == 1:
            LED.on()
            func(False)
            time.sleep(1)
            func(True)
            LED.off()
            time.sleep(1)
    else:
        LED.off()

    
    
